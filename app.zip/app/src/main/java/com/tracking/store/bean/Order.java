package com.tracking.store.bean;

import com.activeandroid.annotation.Column;

import java.util.Date;

/**
 * Created by ZASS on 3/22/2018.
 */

public class Order {
    public int InventoryID;
    public String Product;
    public String Qty;
    public String DateTime;
}

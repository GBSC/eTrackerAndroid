package com.tracking.store;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.tracking.store.util.PrefManager;
import com.tracking.store.web.HttpCaller;
import com.tracking.store.web.WebURL;

import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {


    public HttpCaller httpCaller = HttpCaller.getInstance();

    private Button btnLogin;
    private EditText editTextEmail;
    private EditText editTextPass;

    public PrefManager prefManager = PrefManager.getPrefInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        editTextEmail = (EditText) findViewById(R.id.edittext_userid);
        editTextPass = (EditText) findViewById(R.id.edittext_pass);

        btnLogin = (Button) findViewById(R.id.btn_login);

        editTextEmail.setText("irfan@yahoo.com");
        editTextPass.setText("Irfan12345");

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String userID = editTextEmail.getText().toString();
                String userPass = editTextPass.getText().toString();

                if (userID.equals("") && userPass.equals("")) {
                    Toast.makeText(LoginActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                } else {
                    JSONObject jsonObject = null;
                    try {
                        jsonObject = new JSONObject();
                        jsonObject.put("username", userID);
                        jsonObject.put("password", userPass);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    if (jsonObject != null)
                        httpCaller.requestToServerForLogin(LoginActivity.this, jsonObject, new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    if (response.getBoolean("status")) {
                                        String msg = response.getString("message");
                                        JSONObject responseJson = response.getJSONObject("response");
                                        if (responseJson != null) {
                                            String ticken = responseJson.getString("auth_token");
                                            String userID = responseJson.getString("id");

                                            prefManager.setLogin(true);
                                            prefManager.setUserTockin(ticken);
                                            prefManager.setUserID(userID);

                                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            startActivity(intent);
                                            finish();
                                        }
                                    } else {
                                        String msg = response.getString("message");
                                        showSnackMessage(""+msg);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                            }
                        }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                            }
                        });
                }

            }
        });
    }

    public void showSnackMessage(String msg) {
        Snackbar snackbar = Snackbar.make(getCurrentFocus(), "" + msg,
                Snackbar.LENGTH_LONG);
        View snackbarView = snackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(LoginActivity.this, R.color.color_highlight));
        snackbar.setDuration(5000);
        snackbar.show();
    }
}
/*
    JSONObject jsonObject = new JSONObject();
                    httpCaller.requestToServer(true, LoginActivity.this, WebURL.login, jsonObject, new Response.Listener() {
@Override
public void onResponse(Object response) {

        }
        }, new Response.ErrorListener() {
@Override
public void onErrorResponse(VolleyError error) {

        }
        });*/
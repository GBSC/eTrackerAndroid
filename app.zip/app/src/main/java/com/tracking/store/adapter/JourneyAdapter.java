package com.tracking.store.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import com.tracking.store.R;
import com.tracking.store.StoreDetailActivity;
import com.tracking.store.db.Store;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZASS on 3/20/2018.
 */

public class JourneyAdapter extends RecyclerView.Adapter<JourneyAdapter.ViewHolder> implements Filterable {
    private List<Store> mArrayList;
    private List<Store> mFilteredList;
    private Context context;
    public JourneyAdapter(List<Store> arrayList, Context context) {
        mArrayList = arrayList;
        mFilteredList = arrayList;
        this.context = context;
    }

    @Override
    public JourneyAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.journey_row, viewGroup, false);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.startActivity(new Intent(context, StoreDetailActivity.class));
            }
        });
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(JourneyAdapter.ViewHolder viewHolder, int i) {
        viewHolder.txtShop.setText(mFilteredList.get(i).ShopName+" - "+mFilteredList.get(i).ShopKeeper);
        viewHolder.txt_address.setText(mFilteredList.get(i).City);
    }

    @Override
    public int getItemCount() {
        return mFilteredList.size();
    }

    @Override
    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = mArrayList;
                } else {

                    ArrayList<Store> filteredList = new ArrayList<>();

                    for (Store Store : mArrayList) {

                        if (Store.ShopName.toLowerCase().contains(charString) || Store.ShopKeeper.toLowerCase().contains(charString)) {

                            filteredList.add(Store);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<Store>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txtShop, txt_address;

        public ViewHolder(View view) {
            super(view);

            txtShop = (TextView) view.findViewById(R.id.txtShop);
            txt_address = (TextView) view.findViewById(R.id.txt_address);

        }
    }


}
package com.tracking.store;

import android.app.Activity;
import android.content.Context;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.tracking.store.db.Store;

public class StoreRegistrationActivity extends AppCompatActivity {

    private EditText txtShopName;
    private EditText edittext_shopkeeper;
    private EditText edittext_contactno;
    private EditText edittext_landline;
    private EditText edittext_address;
    private EditText edittext_street;
    private EditText edittext_city;
    private EditText edittext_cnic;

    private Button btn_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_registration);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        setTitle("Store Registration");

        txtShopName = (EditText)findViewById(R.id.txtShopName);
        edittext_shopkeeper = (EditText)findViewById(R.id.edittext_shopkeeper);
        edittext_contactno = (EditText)findViewById(R.id.edittext_contactno);
        edittext_landline = (EditText)findViewById(R.id.edittext_landline);
        edittext_address = (EditText)findViewById(R.id.edittext_address);
        edittext_street = (EditText)findViewById(R.id.edittext_street);
        edittext_city = (EditText)findViewById(R.id.edittext_city);
        edittext_cnic = (EditText)findViewById(R.id.edittext_cnic);


        btn_add = (Button)findViewById(R.id.btn_add);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String ShopName = txtShopName.getText().toString();
                String shopKeeper = edittext_shopkeeper.getText().toString();
                String contactNumber = edittext_contactno.getText().toString();
                String landLine = edittext_landline.getText().toString();
                String address = edittext_address.getText().toString();
                String street = edittext_street.getText().toString();
                String city = edittext_city.getText().toString();
                String cnic = edittext_cnic.getText().toString();

                if(ShopName.equals("") && shopKeeper.equals("") && contactNumber.equals("") && landLine.equals("") && address.equals("") && street.equals("") && city.equals("") && cnic.equals("") ){
                    Toast.makeText(StoreRegistrationActivity.this, "Please fill the all fields", Toast.LENGTH_SHORT).show();
                }else{
                    Store store = new Store();
                    store.ShopName = ShopName;
                    store.ShopKeeper = shopKeeper;
                    store.ContactNumber = contactNumber;
                    store.LandLine = landLine;
                    store.Address = address;
                    store.Street = street;
                    store.City = city;
                    store.CNIC = cnic;
                    store.save();

                    Snackbar snackbar = Snackbar.make(getCurrentFocus(), "Store added successfully",
                            Snackbar.LENGTH_LONG);
                    View snackbarView = snackbar.getView();
                    snackbarView.setBackgroundColor(ContextCompat.getColor(StoreRegistrationActivity.this, R.color.colorPrimary));
                    snackbar.setDuration(5000);
                    snackbar.show();

                    txtShopName.setText("");
                    edittext_shopkeeper.setText("");
                    edittext_contactno.setText("");
                    edittext_landline.setText("");
                    edittext_address.setText("");
                    edittext_street.setText("");
                    edittext_city.setText("");
                    edittext_cnic.setText("");
                }


            }
        });
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}

package com.tracking.store.dbcontroller;

import com.activeandroid.query.Select;
import com.tracking.store.db.Store;

import java.util.List;

/**
 * Created by ZASS on 3/20/2018.
 */

public class DBHandler  {

    public static DBHandler dbHandler = new DBHandler();

    public static DBHandler getInstance(){
        return dbHandler;
    }

    public List<Store> getStoreList(){
        return new Select().from(Store.class).execute();
    }

}

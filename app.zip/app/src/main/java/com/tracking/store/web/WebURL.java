package com.tracking.store.web;

/**
 * Created by ZASS on 3/22/2018.
 */

public class WebURL {

    public static String url = "http://etrackerapp.azurewebsites.net/api/";
    public static String login = url+"Auth/login";
}

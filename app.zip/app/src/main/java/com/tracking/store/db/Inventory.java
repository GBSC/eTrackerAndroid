package com.tracking.store.db;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

import java.util.Date;

/**
 * Created by ZASS on 3/20/2018.
 */

@Table(name = "Inventory")
public class Inventory extends Model {

    @Column(name = "InventoryID")
    public int InventoryID;

    @Column(name = "Inventory")
    public String Inventory;

    @Column(name = "Qty")
    public String Qty;

    @Column(name = "DateTime")
    public Date DateTime;
    
}

package com.tracking.store.util;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefManager {


    public static SharedPreferences sharedPreferences;
    public static PrefManager prefManager;

    public static void getInstance(Context context){
        sharedPreferences = context.getSharedPreferences("eTracking", Context.MODE_PRIVATE);
    }

    public static PrefManager getPrefInstance() {
        if(sharedPreferences != null){
            prefManager = new PrefManager();
            return prefManager;
        }else{
            return null;
        }
    }

    public void logout() {
        if(sharedPreferences != null){
            sharedPreferences.edit().clear().commit();
        }
    }

    public void setLogin(boolean isLogin) {
        if(sharedPreferences != null){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("IsLogin", isLogin);
            editor.commit();
        }
    }

    public void setUserTockin(String tockin) {
        if(sharedPreferences != null){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("UserTockin", tockin);
            editor.commit();
        }
    }

    public void setUserID(String userID) {
        if(sharedPreferences != null){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("UserID", userID);
            editor.commit();
        }
    }


    public boolean isLogin() {
        if(sharedPreferences != null){
            return sharedPreferences.getBoolean("IsLogin", false);
        }else{
            return false;
        }

    }

}
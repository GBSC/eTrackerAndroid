package com.tracking.store.bean;

/**
 * Created by ZASS on 3/22/2018.
 */

public class Inventory {
    public int InventoryID;
    public String Product;
    public String Qty;
    public String DateTime;
}

package com.tracking.store;

import android.app.Application;

import com.activeandroid.ActiveAndroid;
import com.activeandroid.Configuration;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.tracking.store.util.PrefManager;
import com.tracking.store.web.HttpCaller;

/**
 * Created by irfan on 3/19/18.
 */

public class App extends Application {

    HttpCaller httpCaller = HttpCaller.getInstance();
    public static RequestQueue requestQueue;

    @Override
    public void onCreate() {
        super.onCreate();
        PrefManager.getInstance(this);
        Configuration dbConfiguration = new Configuration.Builder(this).setDatabaseName("Evia.db").create();
        ActiveAndroid.initialize(dbConfiguration);
        this.requestQueue = Volley.newRequestQueue(getApplicationContext());

        httpCaller.init(this);
    }
}

package com.tracking.store.fragment;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.tracking.store.R;
import com.tracking.store.adapter.JourneyAdapter;
import com.tracking.store.db.Product;
import com.tracking.store.db.Store;
import com.tracking.store.dbcontroller.DBHandler;
import com.tracking.store.view.OrderDialog;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Irfan Ali on 2/28/2018.
 */

public class OrderFragment extends Fragment {

    private DBHandler dbHandler = DBHandler.getInstance();

    private RecyclerView recyclerView;
    private JourneyAdapter journeyAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.order_fragment, container, false);
        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);

        List<Store> storeList = dbHandler.getStoreList();
        recyclerView = (RecyclerView)view.findViewById(R.id.journey_recycler_view);
        journeyAdapter = new JourneyAdapter(storeList,getActivity());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(journeyAdapter);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<Product> productArrayList = new ArrayList<>();
                OrderDialog orderDialog = new OrderDialog(getActivity(), productArrayList);
                orderDialog.show();
            }
        });

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Do something that differs the Activity's menu here
        super.onCreateOptionsMenu(menu, inflater);
    }

}

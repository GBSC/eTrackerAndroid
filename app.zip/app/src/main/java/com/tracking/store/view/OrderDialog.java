package com.tracking.store.view;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.tracking.store.R;
import com.tracking.store.db.Product;

import java.util.ArrayList;

/**
 * Created by ZASS on 3/22/2018.
 */

public class OrderDialog extends Dialog {

    private Context context;
    private Spinner spinnerProducts;
    private EditText editTextQty;
    private Button addBtn;
    private ArrayList<Product> productArrayList;

    public OrderDialog(Context context, ArrayList<Product> productArrayList) {
        super(context);
        this.context = context;
        this.productArrayList = productArrayList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.order_dialog);
        spinnerProducts  = (Spinner) findViewById(R.id.spinner2);
        editTextQty = (EditText) findViewById(R.id.editTextQty);
        addBtn =(Button)findViewById(R.id.addBtn);

        init();
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String selectedProduct = spinnerProducts.getSelectedItem().toString();
                int qty = Integer.parseInt(editTextQty.getText().toString());
            }
        });
    }

    public void init(){
        //ArrayAdapter<Product> adapter = new ArrayAdapter<Product>(context, R.layout.spinner_row, productArrayList);
        ArrayAdapter<String> spinnerCountShoesArrayAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_dropdown_item, context.getResources().getStringArray(R.array.Products));
       // spinnerCountShoesArrayAdapter.setDropDownViewResource(R.layout.spinner_row);
        spinnerProducts.setAdapter(spinnerCountShoesArrayAdapter);
    }
}


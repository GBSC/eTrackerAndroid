package com.tracking.store.db;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;

/**
 * Created by ZASS on 3/20/2018.
 */

@Table(name = "Store")
public class Store extends Model {

    @Column(name = "ShopName")
    public String ShopName;

    @Column(name = "ShopKeeper")
    public String ShopKeeper;

    @Column(name = "ContactNumber")
    public String ContactNumber;

    @Column(name = "LandLine")
    public String LandLine;

    @Column(name = "Address")
    public String Address;

    @Column(name = "Street")
    public String Street;

    @Column(name = "City")
    public String City;

    @Column(name = "CNIC")
    public String CNIC;

    @Column(name = "Landmark")
    public String Landmark;

    @Column(name = "ImgUrl")
    public String ImgUrl;

    @Column(name = "UserID")
    public String UserID;


}

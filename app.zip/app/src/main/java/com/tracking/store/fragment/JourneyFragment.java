package com.tracking.store.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tracking.store.R;
import com.tracking.store.adapter.JourneyAdapter;
import com.tracking.store.db.Store;
import com.tracking.store.dbcontroller.DBHandler;

import java.util.List;

/**
 * Created by Irfan Ali on 2/28/2018.
 */

public class JourneyFragment extends Fragment {

    private DBHandler dbHandler = DBHandler.getInstance();

    private RecyclerView recyclerView;
    private JourneyAdapter journeyAdapter;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.activity_journey_cycle, container, false);

        List<Store> storeList = dbHandler.getStoreList();
        recyclerView = (RecyclerView)view.findViewById(R.id.journey_recycler_view);
        journeyAdapter = new JourneyAdapter(storeList,getActivity());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(journeyAdapter);

        return view;
    }

    private void search(SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                journeyAdapter.getFilter().filter(newText);
                return true;
            }
        });
    }

}

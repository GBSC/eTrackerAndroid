package com.tracking.store.web;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.tracking.store.App;
import com.tracking.store.R;

import org.json.JSONObject;

/**
 * Created by Irfan Ali on 3/1/2018.
 */

public class HttpCaller {

    public static HttpCaller instance;
    public static Context context;
    private static RetryPolicy retryPolicy;

    public static ProgressDialog progressDialog;

    public static HttpCaller getInstance() {
        if (instance == null) {
            instance = new HttpCaller();
        }
        return instance;
    }

    public boolean init(Context context1) {
        context = context1;
        retryPolicy = new DefaultRetryPolicy(60000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        return true;
    }

    public void setProgressDialog(Context context) {
        progressDialog = ProgressDialog.show(context, null, null, false, true );
        progressDialog.getWindow().setBackgroundDrawable( new ColorDrawable( Color.TRANSPARENT ) );
        progressDialog.setContentView( R.layout.progress_dialog );
        progressDialog.setCancelable(true);
    }

    public void requestToServer(final boolean isShowProgress, final Context context, final String webURL, JSONObject jsonbody, final Response.Listener successLisetenr, final Response.ErrorListener errorLisetenr) {
        if (isShowProgress) {
            setProgressDialog(context);
            progressDialog.show();
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                webURL,
                jsonbody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        if (isShowProgress) {
                            progressDialog.dismiss();
                        }
                        successLisetenr.onResponse(jsonObject);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        if (isShowProgress) {
                            progressDialog.dismiss();
                        }
                        errorLisetenr.onErrorResponse(volleyError);
                    }
                });
        // Setting retry policy
        jsonObjectRequest.setRetryPolicy(retryPolicy).setShouldCache(false).setTag("requestToServer");
        App.requestQueue.add(jsonObjectRequest);
    }

    public void requestToServerForLogin(Context context, JSONObject jsonbody, final Response.Listener successLisetenr, final Response.ErrorListener errorLisetenr) {
        String loginURL = WebURL.login;
        setProgressDialog(context);
        progressDialog.show();
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                loginURL,


                jsonbody,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject jsonObject) {
                        progressDialog.dismiss();
                        successLisetenr.onResponse(jsonObject);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        progressDialog.dismiss();
                        errorLisetenr.onErrorResponse(volleyError);
                    }
                });
        // Setting retry policy
        jsonObjectRequest.setRetryPolicy(retryPolicy).setShouldCache(false).setTag("requestToServer");
        App.requestQueue.add(jsonObjectRequest);
    }

}

package com.tracking.store.util;

/**
 * Created by irfan on 3/19/18.
 */

public class Util {

    public static Util util = new Util();

    public static Util getInstance(){
        return util;
    }


}
